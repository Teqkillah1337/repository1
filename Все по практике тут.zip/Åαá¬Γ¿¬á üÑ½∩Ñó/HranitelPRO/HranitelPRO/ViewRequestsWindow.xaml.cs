﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using HranitelPRO;

namespace HranitelPRO
{
    public partial class ViewRequestsWindow : Window
    {
        private string connectionString = "Data Source=DESKTOP-2VMC5H5\\SQLEXPRESS;Initial Catalog=HranitelPRO;Integrated Security=True";

        public ViewRequestsWindow()
        {
            InitializeComponent();
            LoadRequests();
        }
        private void LoadRequests()
        {
            try
            {
                List<Request> requests = new List<Request>();
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT request_id, request_type, start_date, end_date, purpose, status_name FROM Request INNER JOIN RequestStatus ON Request.status_id = RequestStatus.status_id";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Request request = new Request
                                {
                                    request_id = Convert.ToInt32(reader["request_id"]),
                                    request_type = reader["request_type"].ToString(),
                                    start_date = Convert.ToDateTime(reader["start_date"]),
                                    end_date = Convert.ToDateTime(reader["end_date"]),
                                    purpose = reader["purpose"].ToString(),
                                    status_name = reader["status_name"].ToString()
                                };
                                requests.Add(request);
                            }
                        }
                    }
                }
                RequestsDataGrid.ItemsSource = requests;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заявок: {ex.Message}");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            UserWindow UserWindow = new UserWindow();
            UserWindow.Show();
            this.Close();
        }
    }
}