﻿using System;
using System.Windows;

namespace HranitelPRO
{
    public partial class UserWindow : Window
    {
        public UserWindow()
        {
            InitializeComponent();
        }

        private void CreateRequest_Click(object sender, RoutedEventArgs e)
        {
            MainWindow requestWindow = new MainWindow();
            requestWindow.Show();
            this.Close();
        }

        private void ViewMyRequests_Click(object sender, RoutedEventArgs e)
        {
            ViewRequestsWindow requestsWindow = new ViewRequestsWindow();
            requestsWindow.Show();
            this.Close();
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            FirstWindow firstWindow = new FirstWindow();
            firstWindow.Show();
            this.Close();
        }
    }
}