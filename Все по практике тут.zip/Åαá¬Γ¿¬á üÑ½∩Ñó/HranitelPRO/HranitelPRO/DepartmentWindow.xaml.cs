﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using HranitelPRO;

namespace HranitelPRO
{
    public partial class DepartmentWindow : Window
    {
        private string connectionString = "Data Source=DESKTOP-2VMC5H5\\SQLEXPRESS;Initial Catalog=HranitelPRO;Integrated Security=True";

        public DepartmentWindow()
        {
            InitializeComponent();
            LoadRequests();
            LoadVisitors();
        }

        private void LoadRequests()
        {
            try
            {
                List<Request> requests = new List<Request>();

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    // Запрос изменен, чтобы получить first_name из таблицы Visitor
                    string query = @"SELECT r.request_id, v.first_name, r.start_date, rs.status_name 
                        FROM Request r
                        INNER JOIN Visitor v ON r.user_id = v.visitor_id
                        INNER JOIN RequestStatus rs ON r.status_id = rs.status_id
                        WHERE rs.status_name = 'pending'";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Request request = new Request
                                {
                                    request_id = Convert.ToInt32(reader["request_id"]),
                                    //first_name = reader["first_name"].ToString(), // Больше не присваиваем значение здесь
                                    start_date = Convert.ToDateTime(reader["start_date"]),
                                    status_name = reader["status_name"].ToString(), // Убедитесь, что status_name есть в классе Request
                                    VisitorFirstName = reader["first_name"].ToString() // Вместо этого сохраняем имя посетителя в отдельное свойство
                                };
                                requests.Add(request);
                            }
                        }
                    }
                }
                RequestsDataGrid.ItemsSource = requests;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заявок: {ex.Message}");
            }
        }

        private void LoadVisitors()
        {
            try
            {
                List<Visitor> visitors = new List<Visitor>();
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT visitor_id, first_name, last_name, phone, email FROM Visitor";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Visitor visitor = new Visitor
                                {
                                    visitor_id = Convert.ToInt32(reader["visitor_id"]),
                                    first_name = reader["first_name"].ToString(),
                                    last_name = reader["last_name"].ToString(),
                                    phone = reader["phone"]?.ToString(),
                                    email = reader["email"]?.ToString()
                                };
                                visitors.Add(visitor);
                            }
                        }
                    }
                }
                VisitorsDataGrid.ItemsSource = visitors;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки посетителей: {ex.Message}");
            }
        }

        private void Approve_Click(object sender, RoutedEventArgs e)
        {
            UpdateButtonStatus(sender, "approved");
        }

        private void Reject_Click(object sender, RoutedEventArgs e)
        {
            UpdateButtonStatus(sender, "denied");
        }

        private void UpdateButtonStatus(object sender, string status)
        {
            if (sender is Button button && button.DataContext is Request request)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "UPDATE Request SET status_id = (SELECT status_id FROM RequestStatus WHERE status_name = @status) WHERE request_id = @request_id";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@status", status);
                            command.Parameters.AddWithValue("@request_id", request.request_id);
                            command.ExecuteNonQuery();
                        }
                    }
                    LoadRequests();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка обновления статуса: {ex.Message}");
                }
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            FirstWindow firstWindow = new FirstWindow();
            firstWindow.Show();
            this.Close();
        }
    }
}