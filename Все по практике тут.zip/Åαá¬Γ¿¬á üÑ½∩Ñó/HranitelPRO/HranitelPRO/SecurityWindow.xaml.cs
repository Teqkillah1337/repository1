﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using HranitelPRO;

namespace HranitelPRO
{
    public partial class SecurityWindow : Window
    {
        private string connectionString = "Data Source=DESKTOP-2VMC5H5\\SQLEXPRESS;Initial Catalog=HranitelPRO;Integrated Security=True";

        public SecurityWindow()
        {
            InitializeComponent();
            LoadVisitors();
        }

        private void LoadVisitors()
        {
            try
            {
                List<Visitor> visitors = new List<Visitor>();
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT visitor_id, first_name, last_name, phone, email FROM Visitor";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Visitor visitor = new Visitor
                                {
                                    visitor_id = Convert.ToInt32(reader["visitor_id"]),
                                    first_name = reader["first_name"].ToString(),
                                    last_name = reader["last_name"].ToString(),
                                    phone = reader["phone"]?.ToString(),
                                    email = reader["email"]?.ToString()
                                };
                                visitors.Add(visitor);
                            }
                        }
                    }
                }
                VisitorsDataGrid.ItemsSource = visitors;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки посетителей: {ex.Message}");
            }
        }

        private void ConfirmEntry_Click(object sender, RoutedEventArgs e)
        {
            UpdateVisitorStatus(sender, "entry");
        }

        private void ConfirmExit_Click(object sender, RoutedEventArgs e)
        {
            UpdateVisitorStatus(sender, "exit");
        }

        private void UpdateVisitorStatus(object sender, string status)
        {
            if (sender is Button button && button.DataContext is Visitor visitor)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "UPDATE Visitor SET last_name = @status WHERE visitor_id = @visitor_id";
                        using (SqlCommand command = new SqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@status", status);
                            command.Parameters.AddWithValue("@visitor_id", visitor.visitor_id);
                            command.ExecuteNonQuery();
                        }
                    }
                    LoadVisitors();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка обновления: {ex.Message}");
                }
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            FirstWindow firstWindow = new FirstWindow();
            firstWindow.Show();
            this.Close();
        }
    }
}