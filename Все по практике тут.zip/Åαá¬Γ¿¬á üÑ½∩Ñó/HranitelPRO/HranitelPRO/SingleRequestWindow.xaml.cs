﻿using System;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace HranitelPRO
{
    public partial class SingleRequestWindow : Window
    {
        private string connectionString = "Data Source=Server;Initial Catalog=HranitelPRO;Integrated Security=True";

        public SingleRequestWindow()
        {
            InitializeComponent();
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            //Валидация
            if (string.IsNullOrEmpty(LastNameTextBox.Text) ||
                string.IsNullOrEmpty(FirstNameTextBox.Text) ||
                string.IsNullOrEmpty(PhoneTextBox.Text))
            {
                MessageBox.Show("Заполните обязательные поля (Фамилия, Имя, Телефон)");
                return;
            }

            try
            {
                //Основные данные
                string lastName = LastNameTextBox.Text;
                string firstName = FirstNameTextBox.Text;
                string middleName = MiddleNameTextBox.Text;
                string phone = PhoneTextBox.Text;
                string email = EmailTextBox.Text;
                DateTime visitDate = VisitDatePicker.SelectedDate ?? DateTime.Now;
                string purpose = (PurposeComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();

                // Объявляем newVisitorId ПЕРЕД использованием в запросах
                int newVisitorId = 0;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    //Transaction
                    SqlTransaction transaction = connection.BeginTransaction();

                    try
                    {
                        //Visitor
                        string visitorQuery = "INSERT INTO Visitor (request_id, first_name, last_name, middle_name, phone, email, date_of_birth, passport_series, passport_number, login, password, purpose) " +
                                             "VALUES (@requestId, @firstName, @lastName, @middleName, @phone, @email, @dateOfBirth, @passportSeries, @passportNumber, @login, @password, @purpose); SELECT SCOPE_IDENTITY();";

                        using (SqlCommand visitorCommand = new SqlCommand(visitorQuery, connection, transaction))
                        {
                            visitorCommand.Parameters.AddWithValue("@requestId", 1); // заглушка
                            visitorCommand.Parameters.AddWithValue("@firstName", firstName);
                            visitorCommand.Parameters.AddWithValue("@lastName", lastName);
                            visitorCommand.Parameters.AddWithValue("@middleName", middleName ?? DBNull.Value.ToString());
                            visitorCommand.Parameters.AddWithValue("@phone", phone ?? DBNull.Value.ToString());
                            visitorCommand.Parameters.AddWithValue("@email", email);
                            visitorCommand.Parameters.AddWithValue("@dateOfBirth", DateTime.Now); //Пока DateTime.Now
                            visitorCommand.Parameters.AddWithValue("@passportSeries", "test");  //Test
                            visitorCommand.Parameters.AddWithValue("@passportNumber", "test");  //Test
                            visitorCommand.Parameters.AddWithValue("@login", "test"); //test
                            visitorCommand.Parameters.AddWithValue("@password", "test");  //test
                            visitorCommand.Parameters.AddWithValue("@purpose", purpose);  //Пока

                            // Инициализируем newVisitorId после выполнения запроса
                            newVisitorId = Convert.ToInt32(visitorCommand.ExecuteScalar()); // Get ID
                        }

                        //Request
                        string requestQuery = "INSERT INTO Request (user_id, request_type, start_date, end_date, purpose, subdivision_id, employee_id, status_id, denial_reason) " +
                                             "VALUES (@userId, @requestType, @startDate, @endDate, @purpose, @subdivisionId, @employeeId, @statusId, @denialReason)";

                        using (SqlCommand requestCommand = new SqlCommand(requestQuery, connection, transaction))
                        {
                            requestCommand.Parameters.AddWithValue("@userId", newVisitorId);  // Используем newVisitorId
                            requestCommand.Parameters.AddWithValue("@requestType", "одиночная");
                            requestCommand.Parameters.AddWithValue("@startDate", visitDate);
                            requestCommand.Parameters.AddWithValue("@endDate", visitDate);
                            requestCommand.Parameters.AddWithValue("@purpose", purpose);
                            requestCommand.Parameters.AddWithValue("@subdivisionId", DBNull.Value);
                            requestCommand.Parameters.AddWithValue("@employeeId", DBNull.Value);
                            requestCommand.Parameters.AddWithValue("@statusId", 1); // Статус "pending"
                            requestCommand.Parameters.AddWithValue("@denialReason", DBNull.Value);

                            requestCommand.ExecuteNonQuery();
                        }

                        //Commit
                        transaction.Commit();
                        MessageBox.Show("Заявка успешно отправлена!");
                        BackButton_Click(sender, e);
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();  //Rollback
                        MessageBox.Show($"Ошибка: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}