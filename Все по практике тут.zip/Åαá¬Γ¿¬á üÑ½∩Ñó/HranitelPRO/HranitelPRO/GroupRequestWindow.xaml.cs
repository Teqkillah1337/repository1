﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace HranitelPRO
{
    public partial class GroupRequestWindow : Window
    {
        private string connectionString = "Data Source=DESKTOP-2VMC5H5\\SQLEXPRESS;Initial Catalog=HranitelPRO;Integrated Security=True";
        private List<Visitor> participants = new List<Visitor>();

        public GroupRequestWindow()
        {
            InitializeComponent();
        }

        private void AddParticipant_Click(object sender, RoutedEventArgs e)
        {
            var addWindow = new AddParticipantWindow();
            if (addWindow.ShowDialog() == true)
            {
                participants.Add(addWindow.Participant);
                RefreshParticipantsGrid();
            }
        }

        private void RefreshParticipantsGrid()
        {
            ParticipantsDataGrid.ItemsSource = null;
            ParticipantsDataGrid.ItemsSource = participants;
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            if (participants.Count < 2)
            {
                MessageBox.Show("Групповая заявка должна содержать минимум 2 участника");
                return;
            }

            try
            {
                string organizerName = OrganizerNameTextBox.Text;
                string organizerPhone = OrganizerPhoneTextBox.Text;
                string organization = OrganizationTextBox.Text;
                DateTime visitDate = GroupVisitDatePicker.SelectedDate ?? DateTime.Now;
                string purpose = (GroupPurposeComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
                int participantsCount = participants.Count;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlTransaction transaction = connection.BeginTransaction();

                    try
                    {
                        string requestQuery = "INSERT INTO Request (user_id, request_type, start_date, end_date, purpose, subdivision_id, employee_id, status_id, denial_reason) " +
                                            "VALUES (@userId, @requestType, @startDate, @endDate, @purpose, @subdivisionId, @employeeId, @statusId, @denialReason); " +
                                            "SELECT SCOPE_IDENTITY();";

                        int newRequestId;
                        using (SqlCommand requestCommand = new SqlCommand(requestQuery, connection, transaction))
                        {
                            requestCommand.Parameters.AddWithValue("@userId", 1);
                            requestCommand.Parameters.AddWithValue("@requestType", "групповая");
                            requestCommand.Parameters.AddWithValue("@startDate", visitDate);
                            requestCommand.Parameters.AddWithValue("@endDate", visitDate);
                            requestCommand.Parameters.AddWithValue("@purpose", purpose);
                            requestCommand.Parameters.AddWithValue("@subdivisionId", DBNull.Value);
                            requestCommand.Parameters.AddWithValue("@employeeId", DBNull.Value);
                            requestCommand.Parameters.AddWithValue("@statusId", 1);
                            requestCommand.Parameters.AddWithValue("@denialReason", DBNull.Value);
                            newRequestId = Convert.ToInt32(requestCommand.ExecuteScalar());
                        }

                        foreach (var visitor in participants)
                        {
                            string visitorQuery = "INSERT INTO GroupVisitor (request_id, order_number, first_name, last_name, middle_name, phone, email, date_of_birth, passport_series, passport_number, group_name, login, password, purpose) " +
                                                "VALUES (@requestId, @orderNumber, @firstName, @lastName, @middleName, @phone, @email, @dateOfBirth, @passportSeries, @passportNumber, @groupName, @login, @password, @purpose)";
                            using (SqlCommand visitorCommand = new SqlCommand(visitorQuery, connection, transaction))
                            {
                                visitorCommand.Parameters.AddWithValue("@requestId", newRequestId);
                                visitorCommand.Parameters.AddWithValue("@orderNumber", 1);
                                visitorCommand.Parameters.AddWithValue("@firstName", visitor.first_name);
                                visitorCommand.Parameters.AddWithValue("@lastName", visitor.last_name);
                                visitorCommand.Parameters.AddWithValue("@middleName", visitor.middle_name ?? DBNull.Value.ToString());
                                visitorCommand.Parameters.AddWithValue("@phone", visitor.phone ?? DBNull.Value.ToString());
                                visitorCommand.Parameters.AddWithValue("@email", visitor.email);
                                visitorCommand.Parameters.AddWithValue("@dateOfBirth", visitor.date_of_birth);
                                visitorCommand.Parameters.AddWithValue("@passportSeries", "1234");
                                visitorCommand.Parameters.AddWithValue("@passportNumber", "123456");
                                visitorCommand.Parameters.AddWithValue("@groupName", organization);
                                visitorCommand.Parameters.AddWithValue("@login", "user");
                                visitorCommand.Parameters.AddWithValue("@password", "password");
                                visitorCommand.Parameters.AddWithValue("@purpose", purpose);
                                visitorCommand.ExecuteNonQuery();
                            }
                        }

                        transaction.Commit();
                        MessageBox.Show("Групповая заявка успешно отправлена!");
                        BackButton_Click(sender, e);
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show($"Ошибка: {ex.Message}\n\nПодробности: {ex.InnerException?.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}\n\nПодробности: {ex.InnerException?.Message}");
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            this.Close();
        }
    }
}