﻿using System;
using System.Linq;
using System.Windows;

namespace HranitelPRO
{
    public partial class AddParticipantWindow : Window
    {
        public AddParticipantWindow()
        {
            InitializeComponent();
        }

        public Visitor Participant { get; private set; }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(LastNameTextBox.Text) ||
                string.IsNullOrEmpty(FirstNameTextBox.Text) ||
                string.IsNullOrEmpty(PhoneTextBox.Text))
            {
                MessageBox.Show("Заполните все поля");
                return;
            }

            //Валидация номера телефона
            if (!IsValidPhoneNumber(PhoneTextBox.Text))
            {
                MessageBox.Show("Неверный формат номера телефона.");
                return;
            }

            Participant = new Visitor
            {
                last_name = LastNameTextBox.Text,
                first_name = FirstNameTextBox.Text,
                phone = PhoneTextBox.Text
            };

            DialogResult = true;
            Close();
        }

        //Проверка формата номера телефона
        private bool IsValidPhoneNumber(string phoneNumber)
        {
            //Простая проверка на цифры и длину (можно добавить более сложную логику)
            return phoneNumber.All(char.IsDigit) && phoneNumber.Length >= 7 && phoneNumber.Length <= 15;
        }
    }
}