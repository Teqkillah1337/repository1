﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Data.SqlClient;

namespace HranitelPRO
{
    public partial class AdminWindow : Window
    {
        private string connectionString = "Data Source=DESKTOP-2VMC5H5\\SQLEXPRESS;Initial Catalog=HranitelPRO;Integrated Security=True";

        public AdminWindow()
        {
            InitializeComponent();
            LoadUsers();
        }

        private void LoadUsers()
        {
            List<User> users = new List<User>();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT user_id, email, first_name, last_name, middle_name, phone, date_of_birth, purpose FROM Users";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                User user = new User
                                {
                                    user_id = Convert.ToInt32(reader["user_id"]),
                                    email = reader["email"].ToString(),
                                    first_name = reader["first_name"].ToString(),
                                    last_name = reader["last_name"].ToString(),
                                    middle_name = reader["middle_name"]?.ToString(),
                                    phone = reader["phone"]?.ToString(),
                                    date_of_birth = Convert.ToDateTime(reader["date_of_birth"]),
                                    purpose = reader["purpose"].ToString(),
                                    role = GetUserRole(Convert.ToInt32(reader["user_id"]))
                                };
                                users.Add(user);
                            }
                        }
                    }
                }

                UsersDataGrid.ItemsSource = users;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки пользователей: {ex.Message}");
            }
        }

        private string GetUserRole(int userId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT role FROM UserRoles WHERE user_id = @userId";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@userId", userId);
                        object result = command.ExecuteScalar();
                        return result != null ? result.ToString() : "Пользователь";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки роли пользователя: {ex.Message}");
                return "Пользователь";
            }
        }

        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    foreach (User user in UsersDataGrid.Items)
                    {
                        string updateQuery = "UPDATE UserRoles SET role = @role WHERE user_id = @userId";
                        using (SqlCommand command = new SqlCommand(updateQuery, connection))
                        {
                            command.Parameters.AddWithValue("@role", user.role);
                            command.Parameters.AddWithValue("@userId", user.user_id);
                            command.ExecuteNonQuery();
                        }
                    }
                }
                MessageBox.Show("Изменения сохранены");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения изменений: {ex.Message}");
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            FirstWindow firstWindow = new FirstWindow();
            firstWindow.Show();
            this.Close();
        }

        private void RoleComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (UsersDataGrid.SelectedItem is User selectedUser && sender is ComboBox comboBox)
            {
                selectedUser.role = (string)((ComboBoxItem)comboBox.SelectedItem).Content;
            }
        }
    }

    public class User
    {
        public int user_id { get; set; }
        public string email { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string middle_name { get; set; }
        public string phone { get; set; }
        public DateTime date_of_birth { get; set; }
        public string purpose { get; set; }
        public string role { get; set; }
    }
}