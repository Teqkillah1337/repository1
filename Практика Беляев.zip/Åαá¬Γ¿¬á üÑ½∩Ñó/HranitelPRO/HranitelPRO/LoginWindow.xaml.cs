﻿using System;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;

namespace HranitelPRO
{
    public partial class LoginWindow : Window
    {
        private string connectionString = "Data Source=DESKTOP-2VMC5H5\\SQLEXPRESS;Initial Catalog=HranitelPRO;Integrated Security=True";

        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text;
            string password = PasswordBox.Password;

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT user_id, role FROM Users INNER JOIN UserRoles ON Users.user_id = UserRoles.user_id WHERE email = @email AND password_hash = @password";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@email", email);
                        command.Parameters.AddWithValue("@password", password);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                reader.Read();
                                int userId = reader.GetInt32(0);
                                string role = reader.GetString(1);

                                MessageBox.Show("Авторизация успешна!");

                                switch (role)
                                {
                                    case "Сотрудник":
                                        new DepartmentWindow().Show();
                                        break;
                                    case "Охрана":
                                        new SecurityWindow().Show();
                                        break;
                                    case "Администратор":
                                        new AdminWindow().Show();
                                        break;
                                    default:
                                        new UserWindow().Show();
                                        break;
                                }

                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Неверный email или пароль.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка авторизации: {ex.Message}");
            }
        }

        private void BButton_Click(object sender, RoutedEventArgs e)
        {
            new FirstWindow().Show();
            this.Close();
        }
    }
}