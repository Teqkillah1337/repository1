﻿using System;
using System.Windows;

namespace HranitelPRO
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SingleRequest_Click(object sender, RoutedEventArgs e)
        {
            SingleRequestWindow singleWindow = new SingleRequestWindow();
            singleWindow.Show();
            this.Close();
        }

        private void GroupRequest_Click(object sender, RoutedEventArgs e)
        {
            GroupRequestWindow groupWindow = new GroupRequestWindow();
            groupWindow.Show();
            this.Close();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            UserWindow userWindow = new UserWindow();
            userWindow.Show();
            this.Close();
        }
    }
}