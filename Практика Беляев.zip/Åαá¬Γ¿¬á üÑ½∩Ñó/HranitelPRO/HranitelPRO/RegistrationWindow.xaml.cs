﻿using System;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows;

namespace HranitelPRO
{
    public partial class RegistrationWindow : Window
    {
        private string connectionString = "Data Source=DESKTOP-2VMC5H5\\SQLEXPRESS;Initial Catalog=HranitelPRO;Integrated Security=True";

        public RegistrationWindow()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string lastName = LastNameTextBox.Text;
            string firstName = FirstNameTextBox.Text;
            string middleName = MiddleNameTextBox.Text;
            string phone = PhoneTextBox.Text;
            string email = EmailTextBox.Text;
            string password = PasswordBox.Password;
            string confirmPassword = ConfirmPasswordBox.Password;

            if (string.IsNullOrEmpty(lastName) || string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Пожалуйста, заполните все обязательные поля.");
                return;
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("Пароли не совпадают.");
                return;
            }

            if (!IsValidEmail(email))
            {
                MessageBox.Show("Неверный формат email.");
                return;
            }

            if (!IsValidPhoneNumber(phone))
            {
                MessageBox.Show("Неверный формат номера телефона.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string checkQuery = "SELECT COUNT(*) FROM Users WHERE email = @email";
                    using (SqlCommand checkCommand = new SqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@email", email);
                        int userCount = (int)checkCommand.ExecuteScalar();
                        if (userCount > 0)
                        {
                            MessageBox.Show("Пользователь с таким email уже существует.");
                            return;
                        }
                    }

                    string passwordHash = HashPassword(password);

                    string insertQuery = "INSERT INTO Users (email, password_hash, first_name, last_name, middle_name, phone, date_of_birth, purpose) " +
                                         "VALUES (@email, @passwordHash, @firstName, @lastName, @middleName, @phone, @dateOfBirth, @purpose); SELECT SCOPE_IDENTITY();";
                    int newUserId; 

                    using (SqlCommand insertCommand = new SqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@email", email);
                        insertCommand.Parameters.AddWithValue("@passwordHash", passwordHash);
                        insertCommand.Parameters.AddWithValue("@firstName", firstName);
                        insertCommand.Parameters.AddWithValue("@lastName", lastName);
                        insertCommand.Parameters.AddWithValue("@middleName", string.IsNullOrEmpty(middleName) ? DBNull.Value : (object)middleName);
                        insertCommand.Parameters.AddWithValue("@phone", string.IsNullOrEmpty(phone) ? DBNull.Value : (object)phone);
                        insertCommand.Parameters.AddWithValue("@dateOfBirth", DateTime.Now.Date);
                        insertCommand.Parameters.AddWithValue("@purpose", "Регистрация");
                        newUserId = Convert.ToInt32(insertCommand.ExecuteScalar());
                    }

                    string roleInsertQuery = "INSERT INTO UserRoles (user_id, role) VALUES (@userId, @role)";
                    using (SqlCommand roleInsertCommand = new SqlCommand(roleInsertQuery, connection))
                    {
                        roleInsertCommand.Parameters.AddWithValue("@userId", newUserId);
                        roleInsertCommand.Parameters.AddWithValue("@role", "Пользователь");
                        roleInsertCommand.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Регистрация успешна! Теперь вы можете войти.");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка регистрации: {ex.Message}");
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            FirstWindow firstWindow = new FirstWindow();
            firstWindow.Show();
            this.Close();
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));

                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private bool IsValidPhoneNumber(string phoneNumber)
        {
            return phoneNumber.All(char.IsDigit) && phoneNumber.Length >= 7 && phoneNumber.Length <= 15;
        }
    }
}